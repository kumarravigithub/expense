<?php

namespace Pop\Db\Adapter;

class Exception extends \Exception {}