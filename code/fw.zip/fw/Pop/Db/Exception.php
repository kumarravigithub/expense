<?php

namespace Pop\Db;

class Exception extends \Exception {}