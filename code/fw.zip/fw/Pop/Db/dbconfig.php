<?php

$creds = array(
    'database' => 'cybuzzsc_hisab',
    'host' => 'localhost',
    'username' => 'cybuzzsc',
    'password' => 'KumarRavi#'
);