<?php

namespace Pop\Db\Sql;


class Exception extends \Exception {}