<?php

namespace Pop\Db\Record;


class Exception extends \Exception {}