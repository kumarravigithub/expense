<?php

/**
 * @namespace
 */
namespace Pop\Http;

class Exception extends \Exception {}