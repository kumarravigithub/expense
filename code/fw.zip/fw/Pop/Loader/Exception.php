<?php

namespace Pop\Loader;

class Exception extends \Exception {}