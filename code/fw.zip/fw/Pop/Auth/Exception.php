<?php

namespace Pop\Auth;


class Exception extends \Exception {}