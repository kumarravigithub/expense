<?php

namespace Pop\Auth\Adapter;

class Exception extends \Exception {}